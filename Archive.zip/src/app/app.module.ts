import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { EditorModule } from '@tinymce/tinymce-angular';

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, FormsModule, EditorModule],
  bootstrap: [AppComponent]
})
export class AppModule {}