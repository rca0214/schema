import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  content: string = '<p>Start your template...</p>';
  placeholders = ['{{ClientName}}', '{{Amount}}', '{{Country}}'];

  onDragStart(event: DragEvent, tag: string) {
    event.dataTransfer?.setData('text/plain', tag);
  }

  tinymceInit = {
    height: 400,
    menubar: false,
    plugins: 'lists link code',
    toolbar: 'undo redo | bold italic | bullist numlist | code',
    branding: false,
    setup: (editor: any) => {
      editor.on('init', () => {
        const iframe = document.getElementById('editor_ifr');
        if (iframe) {
          iframe.addEventListener('dragover', e => e.preventDefault());
          iframe.addEventListener('drop', (e: DragEvent) => {
            e.preventDefault();
            const data = e.dataTransfer?.getData('text/plain');
            if (data) {
              editor.insertContent(data);
            }
          });
        }
      });
    }
  };
}